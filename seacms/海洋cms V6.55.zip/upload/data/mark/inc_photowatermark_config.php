<?php
$photo_markup = '0';
$photo_markdown = '0';
$photo_marktype = '1';
$photo_wwidth = '100';
$photo_wheight = '100';
$photo_waterpos = '1';
$photo_watertext = 'www.seacms.net';
$photo_fontsize = '6';
$photo_fontcolor = '#FF0000';
$photo_marktrans = '100';
$photo_diaphaneity = '100';
$photo_markimg = 'mark.gif';
?>
