DROP TABLE IF EXISTS `phpcms_comment_setting`;
