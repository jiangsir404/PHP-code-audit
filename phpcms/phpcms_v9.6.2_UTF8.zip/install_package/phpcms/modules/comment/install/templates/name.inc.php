<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
return array (
      'show_list.html' => '内容页评论列表',
      'list.html' => '评论列表',
    );
?>