<?php
return array(
'pc_version' => 'V9.6.2',	//phpcms 版本号
'pc_release' => '20170503',	//phpcms 更新日期
);
?>